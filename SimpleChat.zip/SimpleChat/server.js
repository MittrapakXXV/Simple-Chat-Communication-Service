require('dotenv').config()

const express = require('express');
const jstoken = require('jsonwebtoken');
const PropertiesReader = require('properties-reader');
const properties = PropertiesReader('config.properties');

const apiUrl = properties.get('api.url');
const dbPort = properties.get('db.port');



const app = express();
const url = new URL(apiUrl);
const HOST = url.hostname;
const PORT = url.port || 3000;


app.use(express.json());

app.get('/', (req, res) => {
  res.send(`
    <h2>Message Server Status : Online ✅</h2>
    <p>Try sending POST to /message</p>
    <p><a href="/downloadJDK">JDK 24</a></p>
    <p><a href="/downloadChat">Chat Client</a></p>
  `);
});


app.get("/downloadJDK", (req, res) => {
    res.download("./downloadable/jdk24.exe", (err) => {
        if (err) {
            console.error('Error downloading file:', err);
            res.status(404).send('File not found');
        }
    });
})
app.get("/downloadChat", (req, res) => {
    res.download("./downloadable/ChatClient.jar", (err) => {
        if (err) {
            console.error('Error downloading file:', err);
            res.status(404).send('File not found');
        }
    });
})


const data = {};
const ID = [];

app.post('/register', (req, res) => {
  const msg = req.body?.RegistererID || '000';
  console.log('Client registering:', msg);
  if (msg == '000') {
    return res.status(403).send({ reply: `not valid` });
  }1

  data[msg] = {}
  ID.push(msg);
  res.json({ Status: true });
});

app.post('/login', (req, res) => {
  const msg = req.body.loginUser;
  console.log('Client login ID Attempt:', ID.find(id => id === msg));
  if (ID.includes(msg)) {
    console.log('Client login Attempt : Success')
    const tok = jstoken.sign({userID : msg, role : 'user'}, process.env.ACCESS_TOKEN_SECRET);//, {expiresIn : '24h'});
    return res.status(200).send({"Token": tok, "Status":true});
  }
  console.log('Client login Attempt : Error')
  res.json({ reply: "Invalid"});
});

const checkToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(" ")[1];  
    if (token === undefined || token == null) {
        return res.status(401).send({"error" : "NGG"})
      }
      jstoken.verify(token,process.env.ACCESS_TOKEN_SECRET,(err,user) =>{
        if (err) return res.status(403).send({"error":"wrong"})
          req.user = user;
          next()
      })
}

app.post('/sendmessage',checkToken, (req, res) => {
  
  const { ReceiverID, Message } = req.body;
  const senderID = req.user.userID;

  if (!ReceiverID || !Message) {
    return res.status(400).json({ Output: 'ReceiverID and Message required' });
  }
  if (!ID.includes(ReceiverID)) {
    return res.status(404).json({ Output: 'No ID Found' });
  }

    if (!data[ReceiverID][senderID]) {
        data[ReceiverID][senderID]={"Messages":[]}
    }

       data[ReceiverID][senderID].Messages.push(Message)
      return res.status(200).json({ Output: `Sent to ${ReceiverID}` });
    
});

app.get('/getAllMessages',checkToken, (req, res) => {
    const senderID = req.user.userID;
     const result = [];
      for (const receiverID in data) {
        for (const senderID in data[receiverID]) {
          result.push({
            receiver: receiverID,
            sender: senderID,
            messages: data[receiverID][senderID].Messages
          });
        }
      }
      console.log(result);
      res.json(result);
      
});

app.get('/getAllMessagesOf',checkToken, (req, res) => {
    const senderID = req.user.userID;
    const receiverID = req.user.userID;

     const result = [];
      if (data[receiverID]) {
        for (const senderID in data[receiverID]) {
          result.push({
            receiver: receiverID,
            sender: senderID,
            messages: data[receiverID][senderID].Messages
          });
        }
      }
      console.log(result);
      res.json(result);
      
});

app.get('/getMessageFrom/:senderID',checkToken, (req, res) => {
    const ownerID = req.user.userID;
    const senderID = req.params.senderID;
      if (!data[ownerID]) {
    return res.status(404).json({ error: "No messages found for this user" });
  }

  if (!data[ownerID][senderID]) {
    return res.status(404).json({ error: `No messages from ${senderID}` });
  }

  return res.json(data[ownerID][senderID].Messages);
      
});




app.listen(PORT, HOST, () => console.log(`🚀 ${HOST}:${PORT}`));
